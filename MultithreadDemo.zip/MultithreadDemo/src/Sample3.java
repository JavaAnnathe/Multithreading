
class SubTask1 extends Thread{
	
	SubTask1(){
		
		 super("Demo Thread");
		 System.out.println("Child thread "+this);
	}
	
	@Override
	public void run() {
		try{
			
			
			for (int n=5; n>0;n--){
				System.out.println("child"+n);
				Thread.sleep(500);
				
			}
		}catch(InterruptedException e){
				
				System.out.println("child thread interrupted");
			}
		System.out.println("child thread exiting");
	}
}


public class Sample3 {

	public static void main(String[] args) {
		SubTask1 s = new SubTask1();
		
		s.start();
		
		
		try{
			
			
			for (int n=5; n>0;n--){
				System.out.println("main"+n);
				Thread.sleep(1000);
				
			}
		}catch(InterruptedException e){
				
				System.out.println("Main thread interrupted");
			}
		System.out.println("Main thread exiting");
	}

}
