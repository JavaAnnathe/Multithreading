class SubTask implements Runnable{
	
	Thread t;
	
	SubTask(){
		
		t = new Thread(this,"Demo Thread");
		System.out.println("Child thread "+t);
	}

	@Override
	public void run() {
		try{
			
			
			for (int n=5; n>0;n--){
				System.out.println("child"+n);
				Thread.sleep(500);
				
			}
		}catch(InterruptedException e){
				
				System.out.println("child thread interrupted");
			}
		System.out.println("child thread exiting");
	}
	
	
	
	
	
	
}


public class Sample2 {
	
	public static void main(String arg[]){
		
		SubTask s = new SubTask();
		
		s.t.start();
		
		
		try{
			
			
			for (int n=5; n>0;n--){
				System.out.println("main"+n);
				Thread.sleep(1000);
				
			}
		}catch(InterruptedException e){
				
				System.out.println("Main thread interrupted");
			}
		System.out.println("Main thread exiting");
	}

}
