class Child implements Runnable{
	
	Thread t;
	
	String name;
	
	Child(String name){
		
		this.name = name;
		t = new Thread(this,name);
		System.out.println("Child thread "+t);
	}

	@Override
	public void run() {
		try{
			
			
			for (int n=5; n>0;n--){
				System.out.println(t.getName()+"  "+n);
				Thread.sleep(500);
				
			}
		}catch(InterruptedException e){
				
				System.out.println("child thread interrupted");
			}
		System.out.println(t.getName()+" thread exiting");
	}
	
	
	
	
	
	
}








public class Sample4 {

	public static void main(String[] args) {
		Child c1 = new Child("child1");
		Child c2 = new Child("child2");
		Child c3 = new Child("child3");
		
		c1.t.start();
		c2.t.start();
		c3.t.start();
	
	
	try{
		
		Thread.sleep(10000);
	}
catch(InterruptedException e){
	
	System.out.println("Main thread interrupted");
}
System.out.println("Main thread exiting");

}
}
