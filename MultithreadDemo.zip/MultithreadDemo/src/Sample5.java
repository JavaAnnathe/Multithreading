
class Kid implements Runnable{
	
	Thread t;
	
	String name;
	
	Kid(String name){
		
		this.name = name;
		t = new Thread(this,name);
		System.out.println("Child thread "+t);
	}

	@Override
	public void run() {
		try{
			
			
			for (int n=5; n>0;n--){
				System.out.println(t.getName()+"  "+n);
				Thread.sleep(500);
				
			}
		}catch(InterruptedException e){
				
				System.out.println("child thread interrupted");
			}
		System.out.println(t.getName()+" thread exiting");
	}
	
	
	
	
	
	
}








public class Sample5 {

	public static void main(String[] args) {
		Kid c1 = new Kid("task1");
		Kid c2 = new Kid("task2");
		Kid c3 = new Kid("task3");
		
		c1.t.start();
		c2.t.start();
		c3.t.start();
	
		System.out.println("task1 is alive "+c1.t.isAlive());
		System.out.println("task2 is alive "+c2.t.isAlive());
		System.out.println("task3 is alive "+c3.t.isAlive());
	try{
		
		c1.t.join();
		System.out.println("task1 is alive "+c1.t.isAlive());
		System.out.println("task2 is alive "+c2.t.isAlive());
		System.out.println("task3 is alive "+c3.t.isAlive());
		c2.t.join();
		c3.t.join();
	}
catch(InterruptedException e){
	
	System.out.println("Main thread interrupted");
}
	
	System.out.println("task1 is alive "+c1.t.isAlive());
	System.out.println("task2 is alive "+c2.t.isAlive());
	System.out.println("task3 is alive "+c3.t.isAlive());
System.out.println("Main thread exiting");

}
}

